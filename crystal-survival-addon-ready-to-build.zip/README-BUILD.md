# Crystal Survival Addon build

Target metadata in this source currently specifies Minecraft 1.21.1, Fabric Loader 0.16.5, Java 21, and Meteor Client `0.5.8-SNAPSHOT`.

## Build in GitHub Actions
1. Create a GitHub repository and upload the *contents of this folder* to its repository root (the `.github` folder must be at the root).
2. Open **Actions** and select **Build Crystal Survival Addon**.
3. Click **Run workflow**. The build must finish successfully before the JAR is considered built.
4. Download the `crystal-survival-addon-jar` artifact from the successful run.

This project has not been verified to compile in the current offline environment. The workflow will reveal any source/API/dependency errors. The addon requires a compatible Meteor Client installation; the JAR is not standalone.
