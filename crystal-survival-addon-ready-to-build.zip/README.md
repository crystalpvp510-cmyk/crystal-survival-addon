# Crystal Survival – Meteor Client Addon

Addon cho **Meteor Client** (Minecraft 1.21.1) tập trung vào sống sót Crystal PvP.

## Modules

| Module | Mô tả |
|--------|--------|
| **Crystal Threat** | Phát hiện End Crystal + ước tính sát thương thực tế |
| **Dead Angle** | Phát hiện bị kẹt / mất lối thoát |
| **Auto Pearl** | Ném Ender Pearl tới vị trí an toàn hơn khi nguy hiểm cao |
| **Auto Defensive Place** | Đặt khối phòng thủ (ưu tiên obsidian) |
| **Mining Handler** | Phối hợp đào khối với totem offhand |
| **Visual Totem** | Chỉ client-side: hiện model Totem trên mainhand |
| **Totem Coordinator** | Điều phối các module để giảm xung đột |

## Yêu cầu

- Minecraft **1.21.1**
- Fabric Loader
- **Meteor Client** (bản tương thích 1.21.1)
- Java 21+

## Build

```bash
./gradlew build
```

JAR nằm ở `build/libs/crystal-survival-1.0.0.jar`.

Đặt file JAR vào thư mục `mods` cùng với `meteor-client-*.jar`.

## Lưu ý quan trọng

- Visual Totem **chỉ thay đổi hình ảnh client**. Server vẫn thấy item thật.
- Auto Pearl **không xuyên obsidian**. Vẫn bị va chạm bình thường.
- Không có bảo đảm thoát khỏi mọi tình huống crystal.
- Các tùy chọn humanize (delay ngẫu nhiên, rotation noise) giúp giảm pattern quá máy móc, **không phải bypass anticheat hoàn hảo**.
- Sử dụng trên server có thể vi phạm quy tắc của server đó.
