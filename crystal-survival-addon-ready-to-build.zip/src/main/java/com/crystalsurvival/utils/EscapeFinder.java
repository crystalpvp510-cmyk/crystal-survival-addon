package com.crystalsurvival.utils;

import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Finds relatively safe positions to pearl to.
 * Does NOT guarantee safety — server can still reject or crystals can still hit.
 */
public final class EscapeFinder {
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    private EscapeFinder() {}

    public static Vec3d findSafePearlPos(PlayerEntity player, double maxRange) {
        if (player == null || mc.world == null) return null;

        List<Candidate> candidates = new ArrayList<>();
        Vec3d eye = player.getEyePos();
        BlockPos origin = player.getBlockPos();

        // Sample directions with slight randomness to look less robotic
        int samples = 24 + ThreadLocalRandom.current().nextInt(8);
        for (int i = 0; i < samples; i++) {
            double yaw = (360.0 / samples) * i + ThreadLocalRandom.current().nextDouble(-6, 6);
            double pitch = ThreadLocalRandom.current().nextDouble(-35, 25); // prefer slightly downward / horizontal

            float yawRad = (float) Math.toRadians(yaw);
            float pitchRad = (float) Math.toRadians(pitch);

            double dx = -MathHelper.sin(yawRad) * MathHelper.cos(pitchRad);
            double dy = -MathHelper.sin(pitchRad);
            double dz = MathHelper.cos(yawRad) * MathHelper.cos(pitchRad);

            Vec3d end = eye.add(dx * maxRange, dy * maxRange, dz * maxRange);

            RaycastContext ctx = new RaycastContext(
                eye, end,
                RaycastContext.ShapeType.COLLIDER,
                RaycastContext.FluidHandling.NONE,
                player
            );
            BlockHitResult hit = mc.world.raycast(ctx);

            Vec3d land;
            if (hit.getType() == HitResult.Type.MISS) {
                land = end;
            } else {
                // Land a bit before the hit surface
                land = hit.getPos().subtract(new Vec3d(dx, dy, dz).normalize().multiply(0.3));
            }

            if (!isReasonableLanding(land, player)) continue;

            double score = scoreLanding(land, player, origin);
            candidates.add(new Candidate(land, score));
        }

        if (candidates.isEmpty()) return null;

        // Prefer higher scores, add small noise so choice isn't always identical
        candidates.sort(Comparator.comparingDouble((Candidate c) -> c.score).reversed());
        int top = Math.min(4, candidates.size());
        return candidates.get(ThreadLocalRandom.current().nextInt(top)).pos;
    }

    private static boolean isReasonableLanding(Vec3d pos, PlayerEntity player) {
        BlockPos bp = BlockPos.ofFloored(pos);
        if (!mc.world.isChunkLoaded(bp)) return false;

        // Must have some air around feet / head
        BlockState feet = mc.world.getBlockState(bp);
        BlockState head = mc.world.getBlockState(bp.up());
        if (feet.isSolidBlock(mc.world, bp) && head.isSolidBlock(mc.world, bp.up())) return false;

        // Don't pearl into void or extremely low
        if (pos.y < player.getY() - 12) return false;

        // Prefer not too close (pearl needs distance to be useful)
        if (pos.squaredDistanceTo(player.getPos()) < 4.0) return false;

        return true;
    }

    private static double scoreLanding(Vec3d pos, PlayerEntity player, BlockPos origin) {
        double score = 0;

        // Prefer distance (escape value)
        double dist = pos.distanceTo(player.getPos());
        score += Math.min(dist, 10.0) * 2.0;

        // Prefer higher Y slightly
        score += (pos.y - player.getY()) * 0.4;

        // Prefer open space (less solid blocks nearby)
        BlockPos bp = BlockPos.ofFloored(pos);
        int solid = 0;
        for (Direction d : Direction.values()) {
            if (mc.world.getBlockState(bp.offset(d)).isSolidBlock(mc.world, bp.offset(d))) solid++;
        }
        score -= solid * 1.5;

        // Slight preference for positions not directly under origin (less predictable)
        if (bp.getX() != origin.getX() || bp.getZ() != origin.getZ()) score += 1.0;

        // Random noise so repeated calls don't always pick the same vector
        score += ThreadLocalRandom.current().nextDouble(-0.8, 0.8);

        return score;
    }

    private record Candidate(Vec3d pos, double score) {}
}
