package com.crystalsurvival.utils;

import meteordevelopment.meteorclient.utils.entity.DamageUtils;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.util.math.Vec3d;

public final class CrystalDamageEstimator {
    private CrystalDamageEstimator() {}

    /**
     * Estimate crystal damage using Meteor's built-in DamageUtils.
     * This respects armor, effects, blocking, and terrain as much as the client can know.
     */
    public static double estimate(EndCrystalEntity crystal, LivingEntity target) {
        if (crystal == null || target == null || !crystal.isAlive()) return 0.0;

        Vec3d pos = crystal.getPos();
        // Meteor DamageUtils.crystalDamage already handles most realistic factors
        return DamageUtils.crystalDamage(target, pos, false, null, false);
    }

    public static double estimateAt(Vec3d crystalPos, LivingEntity target) {
        if (crystalPos == null || target == null) return 0.0;
        return DamageUtils.crystalDamage(target, crystalPos, false, null, false);
    }
}
