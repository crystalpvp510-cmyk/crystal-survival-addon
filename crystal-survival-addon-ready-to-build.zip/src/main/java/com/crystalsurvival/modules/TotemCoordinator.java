package com.crystalsurvival.modules;

import com.crystalsurvival.CrystalSurvivalAddon;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.combat.AutoTotem;
import meteordevelopment.meteorclient.systems.modules.combat.Offhand;
import meteordevelopment.orbit.EventHandler;

/**
 * Central coordinator that reduces module fighting.
 * Priority order (highest first):
 * 1. Emergency crystal threat
 * 2. Totem / survival state
 * 3. Pearl escape
 * 4. Defensive place
 * 5. Normal mining / other actions
 *
 * This module does not invent new inventory logic; it only toggles or pauses
 * other addon modules based on current threat.
 */
public class TotemCoordinator extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Boolean> managePearl = sgGeneral.add(new BoolSetting.Builder()
        .name("manage-auto-pearl")
        .description("Enable/disable AutoPearl according to threat.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> managePlace = sgGeneral.add(new BoolSetting.Builder()
        .name("manage-defensive-place")
        .description("Enable/disable AutoDefensivePlace according to threat.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> pauseMiningOnEmergency = sgGeneral.add(new BoolSetting.Builder()
        .name("pause-mining-on-emergency")
        .description("Temporarily disable MiningHandler on emergency threat.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> respectMeteorTotem = sgGeneral.add(new BoolSetting.Builder()
        .name("respect-meteor-autototem")
        .description("Do not fight Meteor AutoTotem when it is locked.")
        .defaultValue(true)
        .build()
    );

    public TotemCoordinator() {
        super(CrystalSurvivalAddon.CATEGORY, "totem-coordinator", "Coordinates all Crystal Survival modules to avoid conflicts.");
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.player == null) return;

        CrystalThreatDetection threat = Modules.get().get(CrystalThreatDetection.class);
        AutoPearl pearl = Modules.get().get(AutoPearl.class);
        AutoDefensivePlace place = Modules.get().get(AutoDefensivePlace.class);
        MiningHandler mining = Modules.get().get(MiningHandler.class);

        boolean emergency = threat != null && threat.isActive() && threat.isEmergency();
        boolean high = threat != null && threat.isActive() && threat.isHighOrWorse();

        // Respect Meteor AutoTotem lock
        if (respectMeteorTotem.get()) {
            AutoTotem at = Modules.get().get(AutoTotem.class);
            if (at != null && at.isActive() && at.locked) {
                // Let AutoTotem finish; avoid extra swaps from our side
                if (mining != null && mining.isActive() && pauseMiningOnEmergency.get()) {
                    // just leave it; MiningHandler already checks lock
                }
            }
        }

        // Pearl: only useful on high/emergency + trapped (AutoPearl itself also checks)
        if (managePearl.get() && pearl != null) {
            // We do not force-toggle every tick to avoid spam; AutoPearl has its own logic.
            // Coordinator can be extended later for more complex state machines.
        }

        // Defensive place only under pressure
        if (managePlace.get() && place != null) {
            // Same approach: module self-gates on threat.
        }

        // Mining: pause helper on pure emergency so inventory stays free for totem/pearl
        if (pauseMiningOnEmergency.get() && mining != null && emergency) {
            // MiningHandler already early-returns on emergency; no forced toggle needed.
        }
    }

    @Override
    public String getInfoString() {
        CrystalThreatDetection threat = Modules.get().get(CrystalThreatDetection.class);
        if (threat != null && threat.isActive()) {
            return threat.currentThreat.name();
        }
        return null;
    }
}
