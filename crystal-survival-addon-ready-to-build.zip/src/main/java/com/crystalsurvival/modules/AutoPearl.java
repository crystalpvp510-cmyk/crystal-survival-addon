package com.crystalsurvival.modules;

import com.crystalsurvival.CrystalSurvivalAddon;
import com.crystalsurvival.utils.EscapeFinder;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.concurrent.ThreadLocalRandom;

public class AutoPearl extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgAntiCheat = settings.createGroup("AntiCheat");

    private final Setting<Boolean> onlyEmergency = sgGeneral.add(new BoolSetting.Builder()
        .name("only-emergency")
        .description("Only pearl on EMERGENCY threat level.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> requireTrapped = sgGeneral.add(new BoolSetting.Builder()
        .name("require-trapped")
        .description("Also require dead-angle / trapped state.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Double> maxRange = sgGeneral.add(new DoubleSetting.Builder()
        .name("max-pearl-range")
        .description("Maximum pearl target distance.")
        .defaultValue(8.0)
        .min(3.0)
        .max(16.0)
        .sliderMax(16.0)
        .build()
    );

    private final Setting<Integer> baseCooldown = sgGeneral.add(new IntSetting.Builder()
        .name("base-cooldown-ticks")
        .description("Base cooldown between pearl attempts.")
        .defaultValue(25)
        .min(10)
        .max(60)
        .build()
    );

    // Anti-cheat style settings
    private final Setting<Boolean> humanize = sgAntiCheat.add(new BoolSetting.Builder()
        .name("humanize")
        .description("Add small random delays and rotation noise.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Integer> minRotationTicks = sgAntiCheat.add(new IntSetting.Builder()
        .name("min-rotation-ticks")
        .description("Minimum ticks to rotate before throwing.")
        .defaultValue(2)
        .min(0)
        .max(8)
        .visible(humanize::get)
        .build()
    );

    private final Setting<Double> rotationNoise = sgAntiCheat.add(new DoubleSetting.Builder()
        .name("rotation-noise")
        .description("Random yaw/pitch noise degrees.")
        .defaultValue(1.8)
        .min(0.0)
        .max(5.0)
        .visible(humanize::get)
        .build()
    );

    private int cooldown = 0;
    private int rotateTicks = 0;
    private Vec3d pendingTarget = null;
    private boolean rotating = false;

    public AutoPearl() {
        super(CrystalSurvivalAddon.CATEGORY, "auto-pearl", "Throws an ender pearl toward a safer position when threatened.");
    }

    @Override
    public void onActivate() {
        cooldown = 0;
        rotateTicks = 0;
        pendingTarget = null;
        rotating = false;
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;

        if (cooldown > 0) {
            cooldown--;
            return;
        }

        // Finish pending throw after rotation
        if (rotating && pendingTarget != null) {
            rotateTicks++;
            if (rotateTicks >= (humanize.get() ? minRotationTicks.get() : 0)) {
                doThrow();
                rotating = false;
                pendingTarget = null;
                rotateTicks = 0;
                int extra = humanize.get() ? ThreadLocalRandom.current().nextInt(0, 8) : 0;
                cooldown = baseCooldown.get() + extra;
            }
            return;
        }

        CrystalThreatDetection threat = Modules.get().get(CrystalThreatDetection.class);
        DeadAngleDetection angle = Modules.get().get(DeadAngleDetection.class);

        if (threat == null || !threat.isActive()) return;
        if (onlyEmergency.get() && !threat.isEmergency()) return;
        if (requireTrapped.get() && angle != null && angle.isActive()) {
            if (!angle.isTrapped && !angle.isFullyEnclosed) return;
        }

        FindItemResult pearl = InvUtils.findInHotbar(Items.ENDER_PEARL);
        if (!pearl.found()) return;

        Vec3d target = EscapeFinder.findSafePearlPos(mc.player, maxRange.get());
        if (target == null) return;

        pendingTarget = target;
        rotating = true;
        rotateTicks = 0;

        // Start rotating toward target
        aimAt(target);
    }

    private void aimAt(Vec3d target) {
        Vec3d eye = mc.player.getEyePos();
        Vec3d diff = target.subtract(eye);
        double dist = Math.sqrt(diff.x * diff.x + diff.z * diff.z);
        float yaw = (float) Math.toDegrees(Math.atan2(diff.z, diff.x)) - 90.0f;
        float pitch = (float) -Math.toDegrees(Math.atan2(diff.y, dist));

        if (humanize.get()) {
            double noise = rotationNoise.get();
            yaw += (float) ThreadLocalRandom.current().nextDouble(-noise, noise);
            pitch += (float) ThreadLocalRandom.current().nextDouble(-noise * 0.6, noise * 0.6);
        }

        yaw = MathHelper.wrapDegrees(yaw);
        pitch = MathHelper.clamp(pitch, -90f, 90f);

        Rotations.rotate(yaw, pitch);
    }

    private void doThrow() {
        if (pendingTarget == null) return;

        FindItemResult pearl = InvUtils.findInHotbar(Items.ENDER_PEARL);
        if (!pearl.found()) return;

        // Prefer silent swap if possible, otherwise normal
        boolean swapped = false;
        int prev = mc.player.getInventory().selectedSlot;
        if (pearl.slot() != prev) {
            InvUtils.swap(pearl.slot(), false);
            swapped = true;
        }

        mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);

        if (swapped) {
            // small chance to leave the pearl selected a bit longer (more human)
            if (!humanize.get() || ThreadLocalRandom.current().nextInt(100) < 70) {
                InvUtils.swap(prev, false);
            }
        }
    }

    @Override
    public String getInfoString() {
        if (cooldown > 0) return "cd " + cooldown;
        if (rotating) return "aim";
        return null;
    }
}
