package com.crystalsurvival.modules;

import com.crystalsurvival.CrystalSurvivalAddon;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

public class DeadAngleDetection extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Integer> horizontalRadius = sgGeneral.add(new IntSetting.Builder()
        .name("horizontal-radius")
        .description("How far to check for solid walls.")
        .defaultValue(1)
        .min(1)
        .max(3)
        .build()
    );

    private final Setting<Boolean> requireCeiling = sgGeneral.add(new BoolSetting.Builder()
        .name("require-ceiling")
        .description("Treat as fully enclosed only if ceiling is solid.")
        .defaultValue(true)
        .build()
    );

    public boolean isTrapped = false;
    public boolean isFullyEnclosed = false;
    public int openDirections = 4;

    public DeadAngleDetection() {
        super(CrystalSurvivalAddon.CATEGORY, "dead-angle", "Detects when the player is cornered or fully boxed in.");
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.player == null || mc.world == null) {
            isTrapped = false;
            isFullyEnclosed = false;
            openDirections = 4;
            return;
        }

        BlockPos feet = mc.player.getBlockPos();
        int solidSides = 0;
        int open = 0;

        for (Direction dir : Direction.Type.HORIZONTAL) {
            boolean blocked = false;
            for (int r = 1; r <= horizontalRadius.get(); r++) {
                BlockPos check = feet.offset(dir, r);
                BlockState state = mc.world.getBlockState(check);
                BlockState above = mc.world.getBlockState(check.up());

                if (state.isSolidBlock(mc.world, check) || above.isSolidBlock(mc.world, check.up())) {
                    blocked = true;
                    break;
                }
            }
            if (blocked) solidSides++;
            else open++;
        }

        openDirections = open;

        boolean ceilingSolid = false;
        if (requireCeiling.get()) {
            BlockPos ceil = feet.up(2);
            ceilingSolid = mc.world.getBlockState(ceil).isSolidBlock(mc.world, ceil);
        }

        isFullyEnclosed = solidSides >= 3 && (ceilingSolid || !requireCeiling.get());
        isTrapped = solidSides >= 2 && open <= 1;
    }

    @Override
    public String getInfoString() {
        if (isFullyEnclosed) return "FULL";
        if (isTrapped) return "TRAP";
        return openDirections + " open";
    }
}
