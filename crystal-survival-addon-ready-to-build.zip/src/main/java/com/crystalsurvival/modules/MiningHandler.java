package com.crystalsurvival.modules;

import com.crystalsurvival.CrystalSurvivalAddon;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.combat.AutoTotem;
import meteordevelopment.meteorclient.systems.modules.combat.Offhand;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.item.Items;
import net.minecraft.item.PickaxeItem;
import net.minecraft.util.Hand;

/**
 * Helps keep a totem in offhand while still allowing normal mining.
 * Does NOT invent fake tools — real inventory state stays consistent with the server.
 * Works together with Meteor's existing AutoTotem / Offhand modules.
 */
public class MiningHandler extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Boolean> preferKeepTotem = sgGeneral.add(new BoolSetting.Builder()
        .name("prefer-keep-totem")
        .description("Try not to fight AutoTotem for the offhand slot.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> pauseOnEmergency = sgGeneral.add(new BoolSetting.Builder()
        .name("pause-on-emergency")
        .description("Stop extra item switching when crystal threat is emergency.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> switchToPickOnMine = sgGeneral.add(new BoolSetting.Builder()
        .name("switch-pick-on-mine")
        .description("If you start breaking a block and mainhand is not a pick, swap to a pickaxe.")
        .defaultValue(true)
        .build()
    );

    private int lastSelected = -1;

    public MiningHandler() {
        super(CrystalSurvivalAddon.CATEGORY, "mining-handler", "Coordinates mining with totem/offhand so they fight less.");
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.player == null || mc.world == null) return;

        CrystalThreatDetection threat = Modules.get().get(CrystalThreatDetection.class);
        if (pauseOnEmergency.get() && threat != null && threat.isActive() && threat.isEmergency()) {
            return;
        }

        // Respect Meteor AutoTotem lock if present
        AutoTotem autoTotem = Modules.get().get(AutoTotem.class);
        if (preferKeepTotem.get() && autoTotem != null && autoTotem.isActive() && autoTotem.locked) {
            return;
        }

        Offhand offhand = Modules.get().get(Offhand.class);
        if (offhand != null && offhand.isActive() && offhand.locked) {
            return;
        }

        // Simple: if player is mining and mainhand is not a tool, try to put a pick in mainhand
        if (switchToPickOnMine.get() && mc.interactionManager != null && mc.interactionManager.isBreakingBlock()) {
            if (!(mc.player.getMainHandStack().getItem() instanceof PickaxeItem)) {
                var pick = InvUtils.findInHotbar(stack -> stack.getItem() instanceof PickaxeItem);
                if (pick.found() && pick.slot() != mc.player.getInventory().selectedSlot) {
                    lastSelected = mc.player.getInventory().selectedSlot;
                    InvUtils.swap(pick.slot(), false);
                }
            }
        }
    }

    @Override
    public String getInfoString() {
        if (mc.player != null && mc.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) {
            return "totem ok";
        }
        return null;
    }
}
