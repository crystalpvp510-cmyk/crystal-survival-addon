package com.crystalsurvival.modules;

import com.crystalsurvival.CrystalSurvivalAddon;
import com.crystalsurvival.utils.CrystalDamageEstimator;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.util.math.Box;

import java.util.List;

public class CrystalThreatDetection extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Double> range = sgGeneral.add(new DoubleSetting.Builder()
        .name("range")
        .description("Detection range for end crystals.")
        .defaultValue(6.0)
        .min(2.0)
        .max(12.0)
        .sliderMax(12.0)
        .build()
    );

    private final Setting<Double> highThreshold = sgGeneral.add(new DoubleSetting.Builder()
        .name("high-threshold")
        .description("Damage considered high threat.")
        .defaultValue(8.0)
        .min(1.0)
        .sliderMax(20.0)
        .build()
    );

    private final Setting<Double> emergencyThreshold = sgGeneral.add(new DoubleSetting.Builder()
        .name("emergency-threshold")
        .description("Damage considered emergency (near totem pop).")
        .defaultValue(14.0)
        .min(1.0)
        .sliderMax(30.0)
        .build()
    );

    private final Setting<Boolean> prioritizeFeet = sgGeneral.add(new BoolSetting.Builder()
        .name("prioritize-feet")
        .description("Give extra weight to crystals near feet / close range.")
        .defaultValue(true)
        .build()
    );

    public enum ThreatLevel { NONE, LOW, MEDIUM, HIGH, EMERGENCY }

    public ThreatLevel currentThreat = ThreatLevel.NONE;
    public EndCrystalEntity mostDangerous = null;
    public double estimatedDamage = 0.0;

    public CrystalThreatDetection() {
        super(CrystalSurvivalAddon.CATEGORY, "crystal-threat", "Detects nearby end crystals and estimates realistic damage.");
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.player == null || mc.world == null) {
            reset();
            return;
        }

        mostDangerous = null;
        estimatedDamage = 0.0;
        currentThreat = ThreatLevel.NONE;

        Box search = mc.player.getBoundingBox().expand(range.get());
        List<EndCrystalEntity> crystals = mc.world.getEntitiesByClass(
            EndCrystalEntity.class, search, e -> e.isAlive() && !e.isRemoved()
        );

        for (EndCrystalEntity crystal : crystals) {
            double dmg = CrystalDamageEstimator.estimate(crystal, mc.player);

            if (prioritizeFeet.get()) {
                double dy = Math.abs(crystal.getY() - mc.player.getY());
                if (dy < 1.5) dmg *= 1.15; // slight bias for feet crystals
                double dist = crystal.distanceTo(mc.player);
                if (dist < 2.5) dmg *= 1.10;
            }

            if (dmg > estimatedDamage) {
                estimatedDamage = dmg;
                mostDangerous = crystal;
            }
        }

        if (estimatedDamage >= emergencyThreshold.get()) {
            currentThreat = ThreatLevel.EMERGENCY;
        } else if (estimatedDamage >= highThreshold.get()) {
            currentThreat = ThreatLevel.HIGH;
        } else if (estimatedDamage >= 4.0) {
            currentThreat = ThreatLevel.MEDIUM;
        } else if (estimatedDamage > 0.5) {
            currentThreat = ThreatLevel.LOW;
        }
    }

    private void reset() {
        mostDangerous = null;
        estimatedDamage = 0.0;
        currentThreat = ThreatLevel.NONE;
    }

    public boolean isEmergency() {
        return currentThreat == ThreatLevel.EMERGENCY;
    }

    public boolean isHighOrWorse() {
        return currentThreat == ThreatLevel.HIGH || currentThreat == ThreatLevel.EMERGENCY;
    }

    @Override
    public String getInfoString() {
        if (currentThreat == ThreatLevel.NONE) return null;
        return String.format("%s (%.1f)", currentThreat.name(), estimatedDamage);
    }
}
