package com.crystalsurvival.modules;

import com.crystalsurvival.CrystalSurvivalAddon;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.Blocks;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class AutoDefensivePlace extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgAntiCheat = settings.createGroup("AntiCheat");

    private final Setting<Boolean> onlyOnThreat = sgGeneral.add(new BoolSetting.Builder()
        .name("only-on-threat")
        .description("Only place when crystal threat is HIGH or EMERGENCY.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> preferObsidian = sgGeneral.add(new BoolSetting.Builder()
        .name("prefer-obsidian")
        .description("Prefer obsidian over other blocks.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Integer> maxPlacesPerActivation = sgGeneral.add(new IntSetting.Builder()
        .name("max-places")
        .description("Maximum blocks to place before stopping.")
        .defaultValue(3)
        .min(1)
        .max(8)
        .build()
    );

    private final Setting<Integer> placeDelay = sgGeneral.add(new IntSetting.Builder()
        .name("place-delay-ticks")
        .description("Base delay between places.")
        .defaultValue(2)
        .min(0)
        .max(10)
        .build()
    );

    private final Setting<Boolean> humanize = sgAntiCheat.add(new BoolSetting.Builder()
        .name("humanize-delay")
        .description("Add random extra delay ticks.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> avoidSelfTrap = sgAntiCheat.add(new BoolSetting.Builder()
        .name("avoid-self-trap")
        .description("Do not place blocks that fully close the last open direction.")
        .defaultValue(true)
        .build()
    );

    private int delayLeft = 0;
    private int placedThisBurst = 0;

    public AutoDefensivePlace() {
        super(CrystalSurvivalAddon.CATEGORY, "auto-defensive-place", "Places defensive blocks when under crystal pressure.");
    }

    @Override
    public void onActivate() {
        delayLeft = 0;
        placedThisBurst = 0;
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.player == null || mc.world == null) return;

        if (delayLeft > 0) {
            delayLeft--;
            return;
        }

        CrystalThreatDetection threat = Modules.get().get(CrystalThreatDetection.class);
        if (onlyOnThreat.get()) {
            if (threat == null || !threat.isActive() || !threat.isHighOrWorse()) {
                placedThisBurst = 0;
                return;
            }
        }

        if (placedThisBurst >= maxPlacesPerActivation.get()) return;

        FindItemResult block = findBestBlock();
        if (!block.found()) return;

        List<BlockPos> candidates = getDefensivePositions();
        if (candidates.isEmpty()) return;

        // Shuffle a bit so placement order is not always the same
        if (humanize.get() && candidates.size() > 1) {
            int swapIdx = ThreadLocalRandom.current().nextInt(candidates.size());
            BlockPos tmp = candidates.get(0);
            candidates.set(0, candidates.get(swapIdx));
            candidates.set(swapIdx, tmp);
        }

        for (BlockPos pos : candidates) {
            if (avoidSelfTrap.get() && wouldFullyClose(pos)) continue;
            if (!BlockUtils.canPlace(pos, true)) continue;

            if (BlockUtils.place(pos, block, true, 50, true, true)) {
                placedThisBurst++;
                int extra = humanize.get() ? ThreadLocalRandom.current().nextInt(0, 3) : 0;
                delayLeft = placeDelay.get() + extra;
                break;
            }
        }
    }

    private FindItemResult findBestBlock() {
        if (preferObsidian.get()) {
            FindItemResult obs = InvUtils.findInHotbar(Items.OBSIDIAN);
            if (obs.found()) return obs;
        }
        // Any solid block item in hotbar
        return InvUtils.findInHotbar(stack -> {
            Item item = stack.getItem();
            return item instanceof BlockItem bi && bi.getBlock().getDefaultState().isSolidBlock(null, null);
        });
    }

    private List<BlockPos> getDefensivePositions() {
        List<BlockPos> list = new ArrayList<>();
        BlockPos feet = mc.player.getBlockPos();

        // Priority: feet surround style positions that are still air
        for (Direction dir : Direction.Type.HORIZONTAL) {
            BlockPos p = feet.offset(dir);
            if (mc.world.getBlockState(p).isAir()) list.add(p);
        }

        // Optional head-level if under pressure
        for (Direction dir : Direction.Type.HORIZONTAL) {
            BlockPos p = feet.up().offset(dir);
            if (mc.world.getBlockState(p).isAir()) list.add(p);
        }

        return list;
    }

    private boolean wouldFullyClose(BlockPos placePos) {
        DeadAngleDetection angle = Modules.get().get(DeadAngleDetection.class);
        if (angle == null || !angle.isActive()) return false;

        // Rough check: if currently only 1 open direction and we place into that direction, skip
        if (angle.openDirections > 1) return false;

        BlockPos feet = mc.player.getBlockPos();
        for (Direction dir : Direction.Type.HORIZONTAL) {
            BlockPos check = feet.offset(dir);
            if (check.equals(placePos) && angle.openDirections <= 1) return true;
        }
        return false;
    }

    @Override
    public String getInfoString() {
        if (placedThisBurst > 0) return placedThisBurst + "/" + maxPlacesPerActivation.get();
        return null;
    }
}
