package com.crystalsurvival.modules;

import com.crystalsurvival.CrystalSurvivalAddon;
import meteordevelopment.meteorclient.events.render.RenderItemEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

/**
 * CLIENT-SIDE ONLY visual override.
 * Replaces the rendered model of the main-hand item with a Totem when enabled.
 * Does NOT change the actual ItemStack the server knows about.
 * Mining, attacking, and eating still use the real item.
 */
public class VisualTotemOverride extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Boolean> onlyWhenOffhandTotem = sgGeneral.add(new BoolSetting.Builder()
        .name("only-when-offhand-totem")
        .description("Only show fake mainhand totem if offhand already has a real totem.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> hideWhenEmpty = sgGeneral.add(new BoolSetting.Builder()
        .name("hide-when-no-totem")
        .description("Disable visual if player has zero totems left.")
        .defaultValue(true)
        .build()
    );

    public VisualTotemOverride() {
        super(CrystalSurvivalAddon.CATEGORY, "visual-totem", "Client-side only: render a totem model in main hand. Real item stays unchanged.");
    }

    // Note: Meteor's exact render event name can vary by version.
    // RenderItemEvent is used in many Meteor versions; if the signature differs
    // on your exact build, adapt the handler to the current event bus.
    @EventHandler
    private void onRenderItem(RenderItemEvent event) {
        if (mc.player == null) return;
        if (event.hand != Hand.MAIN_HAND) return;

        if (onlyWhenOffhandTotem.get()) {
            if (!mc.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;
        }

        if (hideWhenNoTotems()) return;

        // Replace the stack used for rendering only
        event.stack = new ItemStack(Items.TOTEM_OF_UNDYING);
    }

    private boolean hideWhenNoTotems() {
        if (!hideWhenEmpty.get()) return false;
        int count = 0;
        for (int i = 0; i < mc.player.getInventory().size(); i++) {
            ItemStack s = mc.player.getInventory().getStack(i);
            if (s.isOf(Items.TOTEM_OF_UNDYING)) count += s.getCount();
        }
        return count <= 0;
    }

    @Override
    public String getInfoString() {
        return "visual";
    }
}
