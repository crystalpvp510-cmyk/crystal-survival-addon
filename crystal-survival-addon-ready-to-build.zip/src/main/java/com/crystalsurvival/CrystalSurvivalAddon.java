package com.crystalsurvival;

import com.crystalsurvival.modules.*;
import meteordevelopment.meteorclient.addons.GithubRepo;
import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Modules;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CrystalSurvivalAddon extends MeteorAddon {
    public static final Logger LOG = LoggerFactory.getLogger("CrystalSurvival");
    public static final Category CATEGORY = new Category("Crystal Survival");

    @Override
    public void onInitialize() {
        LOG.info("Crystal Survival Addon initializing...");

        Modules.get().add(new CrystalThreatDetection());
        Modules.get().add(new DeadAngleDetection());
        Modules.get().add(new AutoPearl());
        Modules.get().add(new AutoDefensivePlace());
        Modules.get().add(new MiningHandler());
        Modules.get().add(new VisualTotemOverride());
        Modules.get().add(new TotemCoordinator());

        LOG.info("Crystal Survival Addon loaded successfully");
    }

    @Override
    public void onRegisterCategories() {
        Modules.registerCategory(CATEGORY);
    }

    @Override
    public String getPackage() {
        return "com.crystalsurvival";
    }

    @Override
    public GithubRepo getRepo() {
        return new GithubRepo("crystalsurvival", "crystal-survival-addon");
    }
}
